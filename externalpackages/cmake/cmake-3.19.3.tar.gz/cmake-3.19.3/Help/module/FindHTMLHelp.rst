.. cmake-module:: ../../Modules/FindHTMLHelp.cmake
