#define NAME_LENGTH	80	/* Maximum length of file name */
#define LINE_LENGTH	200	/* Length of input files read at once */

#define MAXDIMS		3	/* Most cuts allowed at one time */
#define MAXSETS		8	/* 2^MAXDIMS */
